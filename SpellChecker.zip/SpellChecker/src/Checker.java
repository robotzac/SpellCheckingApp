//Author Name: Zachery Craft
//Date: 05/27/2021
//Program Name: SpellChecker
//Purpose: Program performs spell checking function by comparing a sample file to a dictionary file

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Checker {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);

		System.out.println("Welcome to the Spell Checker Program! Please enter the dictionary file path: ");

		String dictionaryPath = scanner.nextLine();

		// Upload dictionary file

		File dictionaryFile = new File(dictionaryPath);

		// Read dictionary file as string

		Scanner dictionaryTextScanner = new Scanner(dictionaryFile);

		StringBuilder dictionaryFileContents = new StringBuilder((int) dictionaryFile.length());

		Scanner tempscanner = new Scanner(dictionaryFile);
		while (tempscanner.hasNextLine()) {
			dictionaryFileContents.append(tempscanner.nextLine() + System.lineSeparator());
		}
		String dictinaryString1 = dictionaryFileContents.toString();
		String dictionaryString2 = dictinaryString1;

		System.out.println("Here is the dictionary string: \n" + dictionaryString2);

		// Split dictionary String into Arraylist collection

		List<String> dictionarylist = new ArrayList<String>(Arrays.asList(dictionaryString2.split(",")));

		// Upload sample file

		System.out.println("Please enter the path of the Sample Text file: ");

		String sampleTextPath = scanner.nextLine();

		File sampleTextfile = new File(sampleTextPath);

		// Read sample file as string

		Scanner sampleTextScanner = new Scanner(sampleTextfile);

		StringBuilder sampleFileContents = new StringBuilder((int) sampleTextfile.length());

		Scanner tempscanner2 = new Scanner(sampleTextfile);
		while (tempscanner2.hasNextLine()) {
			sampleFileContents.append(tempscanner2.nextLine() + System.lineSeparator());
		}
		String sampleString = sampleFileContents.toString();
		String sampleString2 = sampleString;

		// Split sample String into ArrayList collection

		List<String> samplelist = Arrays.asList(sampleString2);

		// Begin loop: Any word found in sample text that does not match a word in
		// dictionary file
		// needs to be saved to a variable and printed at the end of the loop.

		System.out.println("Looking for spelling errors...\n");

		for (int i = 0; i < samplelist.size(); i++) {
			String word = samplelist.get(i);
			if (!dictionarylist.contains(word))

				// Found errors? Display them:

				System.out.println("This is an unknown word: " + word + "\n");
		}

		// End program:

		System.out.println("Thanks for using the spellchecker program! Goodbye");

	}

}
